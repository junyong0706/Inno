package com.test.inno;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CustomDialog extends Dialog implements View.OnClickListener {

    private CustomDialogInterface customDialogInterface;
    private Context context;
    private Button key_0, key_1, key_2, key_3, key_4, key_5, key_6, key_7, key_8, key_9, key_reg, key_backspace;

    public String mBtnName;

    //인터페이스 선언
    interface CustomDialogInterface{
        void btnClicked(String btnName);
    }

    //리스너 초기화
    public void setDialogListener(CustomDialogInterface customDialogInterface){
        this.customDialogInterface = customDialogInterface;
    }

    public CustomDialog(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        setContentView(R.layout.num_pad);

        key_0 = findViewById(R.id.key_0);
        key_1 = findViewById(R.id.key_1);
        key_2 = findViewById(R.id.key_2);
        key_3 = findViewById(R.id.key_3);
        key_4 = findViewById(R.id.key_4);
        key_5 = findViewById(R.id.key_5);
        key_6 = findViewById(R.id.key_6);
        key_7 = findViewById(R.id.key_7);
        key_8 = findViewById(R.id.key_8);
        key_9 = findViewById(R.id.key_9);
        key_reg = findViewById(R.id.key_reg);
        key_backspace = findViewById(R.id.key_backspace);

        key_0.setOnClickListener(this);
        key_1.setOnClickListener(this);
        key_2.setOnClickListener(this);
        key_3.setOnClickListener(this);
        key_4.setOnClickListener(this);
        key_5.setOnClickListener(this);
        key_6.setOnClickListener(this);
        key_7.setOnClickListener(this);
        key_8.setOnClickListener(this);
        key_9.setOnClickListener(this);
        key_reg.setOnClickListener(this);
        key_backspace.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        int getId = v.getId();
        if (getId == R.id.key_0) {
            mBtnName = "0";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_1) {
            mBtnName = "1";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_2) {
            mBtnName = "2";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_3) {
            mBtnName = "3";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_4) {
            mBtnName = "4";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_5) {
            mBtnName = "5";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_6) {
            mBtnName = "6";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_7) {
            mBtnName = "7";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_8) {
            mBtnName = "8";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_9) {
            mBtnName = "9";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_reg) {
            mBtnName = "reg";
            customDialogInterface.btnClicked(mBtnName);
        } else if (getId == R.id.key_backspace) {
            mBtnName = "backspace";
            customDialogInterface.btnClicked(mBtnName);
        }


    }
}