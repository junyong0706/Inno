package com.test.inno;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity_org extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_org);

//        if (savedInstanceState == null) {
            Bundle args = new Bundle();
            args.putString("device", "D8:3A:DD:6C:81:A2"); // rasp bluetoothctl show
            Fragment fragment = new TerminalFragment();
            fragment.setArguments(args);
            getSupportFragmentManager().beginTransaction().add(R.id.fragment, fragment, "terminal").addToBackStack(null).commit();
            System.out.println("################시작#################");
//        }
    }
}
